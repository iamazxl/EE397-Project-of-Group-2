clear;

load method2_cache_30.mat;
suc_sum = zeros(1,39);
suc_sum_net = zeros(1,39);
for m = 1:39 %缓存文件数从0-38
    for j =1:10000 %重复计算平均值
        K = 2;   %用户数目，方法一必须为偶数，这里怎么处理可以看论文
        P_max = 1;
        d_i = 1; % i=1,2,...,K
        beta = ones(1,K);
        lambda=ones(1,K);
        lambda(1,2:2:K)=2;
        num_file = 38; %文件数目
        cache_file = m-1;
        epsilon = zeros(1,num_file);
        for i = 1:num_file
            epsilon(i) = 0.016*i;
        end

        use=randi(num_file,1,K);
        epsilon = epsilon(use);
        file = zeros(K,cache_file);
        for i =1:K
            tmp = randperm(num_file);
            file(i,:)=tmp(1,1:cache_file);
        end
        zeta = ones(1,K/2);
        for i = 1:2:K
            zeta((i+1)/2)=(lambda(i)*epsilon(i)*beta(i))/(lambda(i+1)*epsilon(i+1)*beta(i+1));
            if zeta((i+1)/2) < 1
                tmp = lambda(i);
                lambda(i) = lambda(i+1);
                lambda(i+1) = tmp;
                tmp = epsilon(i);
                epsilon(i) = epsilon(i+1);
                epsilon(i+1) = tmp;
                tmp = beta(i);
                beta(i) = beta(i+1);
                beta(i+1) = tmp;
                zeta((i+1)/2) = 1/zeta((i+1)/2);
            end
        end

        S = zeros(3,3);
        for a =1:K
            for b = 1:K
                if ~ismember(use(b),file(a,:))
                    S(a,b)=epsilon(b);
                end
                if ismember(use(b),file(b,:))
                    S(b,:)=0;
                end
            end
        end
        % 写成网络输入的矩阵形式
        S_input = zeros(9,1);
        S_input(1:3,1) = S(1,:);
        S_input(4:6,1) = S(2,:);
        S_input(7:9,1) = S(3,:);
        inputn_S = mapminmax('apply',S_input,inputps); %归一化
        an = sim(net,inputn_S);  %预测
        simu = mapminmax('reverse',an,outputps); %反归一化
        
        [alpha,moda] = cal_a(file,use,lambda,epsilon,beta,zeta);
        P_array=inter_pair(K,P_max,alpha,moda);
        result = zeros(1,K);
        for i = 1:K/2
            [result(2*i-1),result(2*i)] = final(P_array(i),alpha(2*i-1),moda(i),lambda(2*i-1),lambda(2*i),beta(2*i-1),beta(2*i),epsilon(2*i-1),epsilon(2*i));
        end

        suc_pro = sum(result)/K;
        suc_pro_net = eval_reward(S,simu)/(K+1);
        suc_sum(m) =suc_sum(m) + suc_pro;
        suc_sum_net(m) =suc_sum_net(m) + suc_pro_net;
    end
    suc_sum(m)=suc_sum(m)/10000;
    suc_sum_net(m)=suc_sum_net(m)/10000;
end
n_c = suc_sum;
n_c_net = suc_sum_net;

figure
plot(0:38,suc_sum);
hold on;
plot(0:38,suc_sum_net);
legend('method1','method2')
xlabel('cach file');
ylabel('成功概率');


