load va_cache_10.mat
figure
plot(0:38,suc_sum,'-ob','MarkerIndices',1:39,'LineWidth',2,'MarkerSize',3)
hold on;
plot(0:38,suc_sum_net,'-or','MarkerIndices',1:39,'LineWidth',2,'MarkerSize',3)
legend('method1','method2')
xlabel('cach file');
ylabel('成功概率');
title('缓存=10时方法1、2性能对比')

load va_cache_30.mat
figure;
plot(0:38,suc_sum,'-ob','MarkerIndices',1:39,'LineWidth',2,'MarkerSize',3)
hold on;
plot(0:38,suc_sum_net,'-or','MarkerIndices',1:39,'LineWidth',2,'MarkerSize',3)
legend('method1','method2')
xlabel('cach file');
ylabel('成功概率');
title('缓存=30时方法1、2性能对比')